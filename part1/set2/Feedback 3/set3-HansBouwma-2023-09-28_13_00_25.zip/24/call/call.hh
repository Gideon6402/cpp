#ifndef call_hh
#define call_hh

// Declarations go here:
void callValue(string const &prog);
void callRef(string const &prog);

#endif
