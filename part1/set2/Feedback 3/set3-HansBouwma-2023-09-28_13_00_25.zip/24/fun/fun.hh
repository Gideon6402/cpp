#ifndef fun_hh
#define fun_hh

// Declarations go here:
void fun(string str);
void fun2(string const &str);

#endif
