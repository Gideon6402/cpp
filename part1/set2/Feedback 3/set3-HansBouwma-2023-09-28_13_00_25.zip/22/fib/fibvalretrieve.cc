#include "fib.ih"

size_t fibvalretrieve(size_t value, size_t fibval[])
{
    return fibval[value];
};
