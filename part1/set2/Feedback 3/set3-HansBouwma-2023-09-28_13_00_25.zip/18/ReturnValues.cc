// ML: Why is this here?
// #include <iostream>
// using namespace std;              // put in or outside struct?
