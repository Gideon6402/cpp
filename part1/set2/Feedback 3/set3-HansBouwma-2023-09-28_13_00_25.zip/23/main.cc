// ML: 0
#include "main.ih"

int main(int argc, char **argv)
{
    cout << "Hello world!" << '\n';
};
