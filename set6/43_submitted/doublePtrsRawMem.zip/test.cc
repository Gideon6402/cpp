#include <iostream>
#include <iomanip>

int main()
{
    // std::cout << setiosflags(std::ios_base::fixed, std::ios_base::floatfield) << 5.0 << '\n';
}