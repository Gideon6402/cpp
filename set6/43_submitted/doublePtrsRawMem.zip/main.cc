#include "main.ih"

int main()
{
    Strings strings;
    for (size_t poging = 0; poging != 18; ++poging)
    {
        strings.add(to_string(poging));
    }
    cout << strings.at(17) << '\n';
}
